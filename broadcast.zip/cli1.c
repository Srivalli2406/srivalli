#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <signal.h>
#include <arpa/inet.h>
#include <stdlib.h>
#define PORT 8080
int main(){
	int sock=0,val_read;
	struct sockaddr_in serv_addr;
	char *msg="hello from client";
	char buf[1024]={0};
	
	int addrlen=sizeof(serv_addr);
	if((sock=socket(AF_INET,SOCK_STREAM,0))<0){
		perror("socket is not connected\n");
		exit(EXIT_FAILURE);
		}
	 serv_addr.sin_family = AF_INET;
   	serv_addr.sin_port = htons(PORT);
	
	if(inet_pton(AF_INET,"127.0.0.1",&serv_addr.sin_addr)<=0)
	{
		printf("Invalid address\n");
		exit(EXIT_FAILURE);
	}
	if(connect(sock,(struct sockaddr *)&serv_addr,sizeof(serv_addr))<0)
	{
		printf("Connection failed\n");
		exit(EXIT_FAILURE);
	}
	
	val_read=read(sock,buf,1024);
	printf("message from server : %s",buf);
	}
