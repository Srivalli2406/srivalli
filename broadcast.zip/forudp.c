#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <errno.h>

#define PORT 8080
#define MAX 3

int main() {
    int server_fd, new_socket[MAX];
    struct sockaddr_in address;
    int addrlen = sizeof(address);

    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    if (bind(server_fd, (struct sockaddr *)&address, addrlen) < 0) {
        perror("Binding failed");
        exit(EXIT_FAILURE);
    }

    if (listen(server_fd, MAX) < 0) {
        perror("Listen failed");
        exit(EXIT_FAILURE);
    }

    char msg[100];
 
    while (1) {
       for (int i = 0; i < MAX; i++) {
   
            if ((new_socket[i]= accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen)) < 0) {
                perror("Accept failed");
                exit(EXIT_FAILURE);
            }
        }

    printf("enter the msg : ");
    scanf("%s",msg);

        for (int i = 0; i < MAX; i++) {
            send(new_socket[i], msg, strlen(msg), 0);
            //close(new_socket[i]); // Close each client socket
        }

        printf("Message sent to clients\n");
    }

    close(server_fd);

    return 0;
}

